# Tergapai — Android native starter project

This is a native Android app project (Kotlin + Android framework), not a web app or WebView wrapper.

## Features in this starter
- Multiple savings targets
- Set target amount and deadline with Android date picker
- Daily average required recalculates from remaining amount and calendar days
- Add deposits and optional notes; each target has separate history
- Edit/delete target
- Saves data locally on the device using SharedPreferences

## Build APK
This workspace did not have Android SDK or Gradle installed, so an APK could not be compiled here. To build it:
1. Install Android Studio on a computer.
2. Open the `TergapaiAndroid` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by Android Studio.
4. Select **Build > Build APK(s)**.
5. Android Studio will show the generated APK location.

This is a starter build, not yet a fully tested release. Test it with non-critical sample data before relying on it.
