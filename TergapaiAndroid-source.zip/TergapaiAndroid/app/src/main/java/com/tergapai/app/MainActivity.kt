package com.tergapai.app

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.ceil

private const val GREEN = 0xFF17352D.toInt()
private const val MINT = 0xFFD8F2B8.toInt()
private const val GOLD = 0xFFD5A64B.toInt()
private const val INK = 0xFF202521.toInt()
private const val MUTED = 0xFF6F7771.toInt()
private const val PAPER = 0xFFF7F7F2.toInt()

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("tergapai_data", MODE_PRIVATE) }
    private val money = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale("id", "ID"))
    private var targets = JSONArray()
    private var content: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = GREEN
        window.navigationBarColor = GREEN
        loadData()
        showHome()
    }

    private fun loadData() { targets = try { JSONArray(prefs.getString("targets", "[]")) } catch (_: Exception) { JSONArray() } }
    private fun saveData() { prefs.edit().putString("targets", targets.toString()).apply() }
    private fun rupiah(n: Long): String = "Rp" + NumberFormat.getNumberInstance(Locale("in", "ID")).format(n)
    private fun today(): Long = startOfDay(System.currentTimeMillis())
    private fun startOfDay(t: Long): Long { val c = Calendar.getInstance(); c.timeInMillis = t; c.set(Calendar.HOUR_OF_DAY,0); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0); return c.timeInMillis }
    private fun daysLeft(deadline: Long): Int = (((startOfDay(deadline) - today()) / 86400000L).toInt() + 1).coerceAtLeast(0)
    private fun saved(t: JSONObject): Long { var total = 0L; val a=t.optJSONArray("deposits") ?: JSONArray(); for(i in 0 until a.length()) total += a.optJSONObject(i)?.optLong("amount",0L) ?: 0L; return total }

    private fun baseScreen(title: String, subtitle: String? = null): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(PAPER) }
        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(28)) }
        val brand = TextView(this).apply { text = "tergapai"; textSize = 25f; setTextColor(GREEN); typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        col.addView(brand)
        val heading = TextView(this).apply { text = title; textSize = 23f; setTextColor(INK); typeface = Typeface.create("sans-serif", Typeface.BOLD); setPadding(0, dp(22), 0, dp(3)) }
        col.addView(heading)
        if (subtitle != null) col.addView(TextView(this).apply { text = subtitle; textSize = 14f; setTextColor(MUTED); setPadding(0, 0, 0, dp(14)) })
        scroll.addView(col); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f)); setContentView(root); content=col
        return col
    }
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun addText(parent: LinearLayout, text: String, size: Float=15f, color: Int=INK, bold: Boolean=false, top: Int=8) {
        parent.addView(TextView(this).apply { this.text=text; textSize=size; setTextColor(color); if(bold) typeface=Typeface.create("sans-serif",Typeface.BOLD); setPadding(0,dp(top),0,dp(3)) })
    }
    private fun button(parent: LinearLayout, text: String, onClick: () -> Unit, filled: Boolean=true) {
        val b = Button(this).apply { this.text=text; isAllCaps=false; textSize=15f; setTextColor(if(filled) Color.WHITE else GREEN); if(filled) setBackgroundTintList(android.content.res.ColorStateList.valueOf(GREEN)) else setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFE6EDE5.toInt())); setOnClickListener { onClick() } }
        val lp = LinearLayout.LayoutParams(-1, dp(50)); lp.topMargin=dp(10); parent.addView(b,lp)
    }
    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(12),dp(16),dp(16)); setBackgroundColor(Color.WHITE) }
        val lp=LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(10); parent.addView(c,lp); return c
    }
    private fun showHome() {
        val col=baseScreen("Tujuanmu, satu per satu.", "Catat progres kecilmu sampai target tergapai.")
        val total= (0 until targets.length()).sumOf { saved(targets.optJSONObject(it) ?: JSONObject()) }
        val summary=card(col); summary.setBackgroundColor(GREEN)
        addText(summary,"TOTAL TABUNGAN",12f,MINT,true,2); addText(summary,rupiah(total),27f,Color.WHITE,true,4)
        button(col,"+  Buat target baru", { createTarget() })
        addText(col,"Target tabungan",18f,INK,true,18)
        if(targets.length()==0) {
            val empty=card(col); addText(empty,"Belum ada target",17f,INK,true,3); addText(empty,"Buat target pertama dan Tergapai akan menghitung kebutuhan tabungan harianmu.",14f,MUTED,false,4)
        } else {
            for(i in 0 until targets.length()) {
                val t=targets.optJSONObject(i) ?: continue
                val c=card(col); val amount=t.optLong("amount",0); val balance=saved(t); val remain=(amount-balance).coerceAtLeast(0); val deadline=t.optLong("deadline",today()); val days=daysLeft(deadline); val avg=if(remain==0L) 0L else if(days>0) ceil(remain.toDouble()/days).toLong() else remain
                addText(c,t.optString("name","Target"),18f,INK,true,2); addText(c,rupiah(balance)+" dari "+rupiah(amount),14f,MUTED,false,4)
                val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=if(amount>0) ((balance.toDouble()/amount)*100).toInt().coerceIn(0,100) else 0; progressTintList=android.content.res.ColorStateList.valueOf(GREEN); progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFFE4E8E2.toInt()) }
                val lp=LinearLayout.LayoutParams(-1,dp(7)); lp.topMargin=dp(10); c.addView(bar,lp)
                addText(c,if(remain==0L) "Target tercapai! 🎉" else "Sisa ${rupiah(remain)} · rata-rata ${rupiah(avg)}/hari",13f,if(remain==0L) GREEN else MUTED,false,6)
                addText(c,"Tenggat: "+dateFmt.format(Date(deadline)),13f,MUTED,false,4)
                button(c,"Buka target",{ showDetail(i) },false)
            }
        }
        addText(col,"Data tersimpan di HP ini.",12f,MUTED,false,18)
    }
    private fun createTarget() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0) }
        val name=EditText(this).apply { hint="Nama target (contoh: Modal usaha)" }
        val amount=EditText(this).apply { hint="Nominal target (Rp)"; inputType=2 }
        val date=TextView(this).apply { text="Tenggat: pilih tanggal"; textSize=15f; setTextColor(GREEN); setPadding(0,dp(16),0,dp(16)) }
        var deadline=today()+30*86400000L
        fun updateDate(){ date.text="Tenggat: "+dateFmt.format(Date(deadline)) }
        date.setOnClickListener { val c=Calendar.getInstance(); c.timeInMillis=deadline; DatePickerDialog(this,{_,y,m,d-> val x=Calendar.getInstance(); x.set(y,m,d,0,0,0); x.set(Calendar.MILLISECOND,0); deadline=x.timeInMillis; updateDate() },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }
        updateDate(); box.addView(name); box.addView(amount); box.addView(date)
        AlertDialog.Builder(this).setTitle("Buat target baru").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create().also { dialog -> dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener { val n=name.text.toString().trim(); val a=amount.text.toString().toLongOrNull(); if(n.isBlank() || a==null || a<=0) { Toast.makeText(this,"Isi nama dan nominal target dengan benar.",Toast.LENGTH_SHORT).show() } else if(deadline<today()) { Toast.makeText(this,"Pilih tenggat hari ini atau setelahnya.",Toast.LENGTH_SHORT).show() } else { val t=JSONObject().put("name",n).put("amount",a).put("deadline",deadline).put("deposits",JSONArray()); targets.put(t); saveData(); dialog.dismiss(); showHome() } } }; dialog.show() }
    }
    private fun showDetail(index: Int) {
        val t=targets.optJSONObject(index) ?: return
        val col=baseScreen(t.optString("name","Target"),"Progres menuju targetmu")
        val amount=t.optLong("amount",0); val balance=saved(t); val remain=(amount-balance).coerceAtLeast(0); val deadline=t.optLong("deadline",today()); val days=daysLeft(deadline); val avg=if(remain==0L)0L else if(days>0) ceil(remain.toDouble()/days).toLong() else remain
        val c=card(col); addText(c,"SUDAH TERKUMPUL",12f,MUTED,true,2); addText(c,rupiah(balance),28f,GREEN,true,4); addText(c,"dari ${rupiah(amount)}",14f,MUTED,false,2)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=if(amount>0)((balance.toDouble()/amount)*100).toInt().coerceIn(0,100) else 0; progressTintList=android.content.res.ColorStateList.valueOf(GREEN) }; c.addView(bar,LinearLayout.LayoutParams(-1,dp(8)))
        addText(c,"${if(amount>0)((balance.toDouble()/amount)*100).toInt() else 0}% tercapai",14f,GREEN,true,8)
        val stats=card(col); addText(stats,"Sisa target",12f,MUTED,false,2); addText(stats,rupiah(remain),19f,INK,true,0); addText(stats,"Rata-rata kebutuhan harian",12f,MUTED,false,12); addText(stats,if(remain==0L) "Target tercapai! 🎉" else rupiah(avg)+" / hari",19f,INK,true,0); addText(stats,"Tenggat: "+dateFmt.format(Date(deadline))+if(days>0) " · $days hari tersisa" else " · tenggat lewat",13f,MUTED,false,8)
        button(col,"+  Tambah setoran",{ addDeposit(index) })
        addText(col,"Riwayat setoran",18f,INK,true,18)
        val deposits=t.optJSONArray("deposits") ?: JSONArray()
        if(deposits.length()==0) { val h=card(col); addText(h,"Belum ada setoran yang dicatat.",14f,MUTED,false,2) }
        else for(j in deposits.length()-1 downTo 0) { val d=deposits.optJSONObject(j) ?: continue; val h=card(col); addText(h,"+ "+rupiah(d.optLong("amount",0)),16f,GREEN,true,2); addText(h,dateFmt.format(Date(d.optLong("date",today()))),13f,MUTED,false,2); if(d.optString("note").isNotBlank()) addText(h,d.optString("note"),13f,INK,false,2) }
        button(col,"Ubah target",{ editTarget(index) },false)
        button(col,"Hapus target",{ AlertDialog.Builder(this).setTitle("Hapus target?").setMessage("Target dan riwayat setorannya akan dihapus dari HP ini.").setNegativeButton("Batal",null).setPositiveButton("Hapus"){_,_-> val next=JSONArray(); for(k in 0 until targets.length()) if(k!=index) next.put(targets.opt(k)); targets=next; saveData(); showHome() }.show() },false)
        button(col,"← Kembali ke beranda",{showHome()},false)
    }
    private fun addDeposit(index:Int) {
        val t=targets.optJSONObject(index) ?: return
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0) }
        val amount=EditText(this).apply { hint="Nominal setoran (Rp)"; inputType=2 }
        val note=EditText(this).apply { hint="Catatan (opsional)" }
        box.addView(amount); box.addView(note)
        AlertDialog.Builder(this).setTitle("Tambah setoran").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create().also { dialog -> dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener { val a=amount.text.toString().toLongOrNull(); if(a==null||a<=0) Toast.makeText(this,"Masukkan nominal yang valid.",Toast.LENGTH_SHORT).show() else { val arr=t.optJSONArray("deposits") ?: JSONArray(); arr.put(JSONObject().put("amount",a).put("date",today()).put("note",note.text.toString().trim())); t.put("deposits",arr); saveData(); dialog.dismiss(); showDetail(index) } } }; dialog.show() }
    }
    private fun editTarget(index:Int) {
        val t=targets.optJSONObject(index) ?: return
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(8),dp(20),0) }
        val name=EditText(this).apply { setText(t.optString("name")); hint="Nama target" }
        val amount=EditText(this).apply { setText(t.optLong("amount").toString()); hint="Nominal target (Rp)"; inputType=2 }
        var deadline=t.optLong("deadline",today())
        val date=TextView(this).apply { text="Tenggat: "+dateFmt.format(Date(deadline)); textSize=15f; setTextColor(GREEN); setPadding(0,dp(16),0,dp(16)) }
        date.setOnClickListener { val c=Calendar.getInstance(); c.timeInMillis=deadline; DatePickerDialog(this,{_,y,m,d->val x=Calendar.getInstance();x.set(y,m,d,0,0,0);x.set(Calendar.MILLISECOND,0);deadline=x.timeInMillis;date.text="Tenggat: "+dateFmt.format(Date(deadline))},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }
        box.addView(name);box.addView(amount);box.addView(date)
        AlertDialog.Builder(this).setTitle("Ubah target").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create().also { dialog -> dialog.setOnShowListener { dialog.getButton(-1).setOnClickListener { val n=name.text.toString().trim(); val a=amount.text.toString().toLongOrNull(); if(n.isBlank()||a==null||a<=0||deadline<today()) Toast.makeText(this,"Periksa nama, nominal, dan tenggat.",Toast.LENGTH_SHORT).show() else { t.put("name",n).put("amount",a).put("deadline",deadline);saveData();dialog.dismiss();showDetail(index) } } };dialog.show() }
    }
}
